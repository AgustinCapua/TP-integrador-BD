-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-11-2023 a las 22:22:23
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `integrador_cac`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oradores`
--

CREATE TABLE `oradores` (
  `Id_orador` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Mail` varchar(100) NOT NULL,
  `Tema` varchar(100) NOT NULL,
  `Fecha_alta` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `oradores`
--

INSERT INTO `oradores` (`Id_orador`, `Nombre`, `Apellido`, `Mail`, `Tema`, `Fecha_alta`) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', 'Tema1', '2023-11-07'),
(2, 'Juliana', 'Varela', 'julianavarela@hotmail.com', 'tema2', '2023-11-08'),
(3, 'Camila', 'Capua', 'camilacapua@gmail.com', 'tema3', '2023-11-15'),
(4, 'Juan', 'Pablo', 'juanpablo@yahoo.com', 'tema4', '2023-11-07'),
(5, 'Nicolas', 'Caballero', 'nicocaba@yahoo.com', 'tema5', '2023-11-06'),
(6, 'Daniel', 'Andria', 'daniel003@hotmail.com', 'tema6', '2023-11-22'),
(7, 'Javier', 'Di Martino', 'javierdimartino@gmail.com', 'tema7', '2023-12-20'),
(8, 'Matias', 'Coronel', 'matiascoronel@gmail.com', 'tema8', '2023-11-19'),
(9, 'Lourdes', 'Cabral', 'lourdescabral@hotmail.com', 'tema9', '2023-11-30'),
(10, 'Justin', 'Bieber', 'justin@gmail.com', 'tema10', '2023-11-01');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `oradores`
--
ALTER TABLE `oradores`
  ADD PRIMARY KEY (`Id_orador`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `oradores`
--
ALTER TABLE `oradores`
  MODIFY `Id_orador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
